module.exports = [
    // Add amp column to posts
    require('./01-add-amp-column-to-posts')
];
